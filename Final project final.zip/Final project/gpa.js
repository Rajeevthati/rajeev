
window.addEventListener("load", () => {
    document.getElementById("cr1").focus();
});
function points(letter) {
    if (!letter) return null;
    letter = letter.toUpperCase();

    if (letter === "A") return 4.0;
    if (letter === "B") return 3.0;
    if (letter === "C") return 2.0;
    if (letter === "D") return 1.0;
    if (letter === "F") return 0.0;
    return null;
}
function calGpa() {
    let total = 0;        
    let totalhours = 0; 
    let count = 0;     
    for (let i = 1; i <= 5; i++) {
        let hours1 = document.getElementById("cr" + i).value;
        let grade1 = document.getElementById("gr" + i).value;
        if (hours1 === "" && grade1 === "") {
            continue;
        }
        let hours = parseFloat(hours1);
        let grade = points(grade1);
        if (isNaN(hours) || grade === null) {
            alert("Check Course " + i + ": Enter valid credit hours and grade A, B, C, D, or F.");
            return;
        }
        total += hours * grade; 
        totalhours += hours;
        count++;
    }
    if (count < 2) {
        alert("Enter at least 2 courses.");
        return;
    }
    let gpa = total / totalhours;
    document.getElementById("avgGpa").value = gpa.toFixed(2);
}
function reset() {
    for (let i = 1; i <= 5; i++) {
        document.getElementById("cr" + i).value = "";
        document.getElementById("gr" + i).value = "";
    }
    document.getElementById("avgGpa").value = "";
    document.getElementById("cr1").focus();
}
